export class Hero {

    constructor(
        public uname: string,
        public pass: string,
        public aname: string,
        public apass: string,
        public email: string,
        public anumber: string,
        public city: string

      ) {  }
      
}


